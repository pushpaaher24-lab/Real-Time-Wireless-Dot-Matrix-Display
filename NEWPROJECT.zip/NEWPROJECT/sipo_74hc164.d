sipo_74hc164.o: sipo_74hc164.c
sipo_74hc164.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
sipo_74hc164.o: defines.h
sipo_74hc164.o: types.h
sipo_74hc164.o: delay.h
sipo_74hc164.o: types.h
