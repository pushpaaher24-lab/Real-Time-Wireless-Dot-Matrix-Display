dot.o: dot.c
dot.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
dot.o: defines.h
dot.o: types.h
dot.o: delay.h
dot.o: types.h
dot.o: sipo_74hc164.h
dot.o: types.h
