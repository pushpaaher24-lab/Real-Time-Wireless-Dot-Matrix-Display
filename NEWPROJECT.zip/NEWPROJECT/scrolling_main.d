scrolling_main.o: scrolling_main.c
scrolling_main.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
scrolling_main.o: fixed_string.h
scrolling_main.o: types.h
scrolling_main.o: sipo_74hc164.h
scrolling_main.o: types.h
