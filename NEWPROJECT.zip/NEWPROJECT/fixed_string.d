fixed_string.o: fixed_string.c
fixed_string.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
fixed_string.o: defines.h
fixed_string.o: types.h
fixed_string.o: delay.h
fixed_string.o: types.h
fixed_string.o: sipo_74hc164.h
fixed_string.o: types.h
