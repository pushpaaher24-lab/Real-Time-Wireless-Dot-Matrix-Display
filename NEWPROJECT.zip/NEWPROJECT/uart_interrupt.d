uart_interrupt.o: uart_interrupt.c
uart_interrupt.o: C:\KeilARM\ARM\INC\Philips\LPC21xx.H
uart_interrupt.o: C:\KeilARM\ARM\RV31\INC\string.h
uart_interrupt.o: types.h
uart_interrupt.o: uart_interrupt.h
uart_interrupt.o: delay.h
uart_interrupt.o: types.h
